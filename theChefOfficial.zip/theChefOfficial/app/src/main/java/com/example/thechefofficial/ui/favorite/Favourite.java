package com.example.thechefofficial.ui.favorite;

public class Favourite {

    String id;
    String imgId;

    public Favourite() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getImgId() {
        return imgId;
    }

    public void setImgId(String imgId) {
        this.imgId = imgId;
    }




}
