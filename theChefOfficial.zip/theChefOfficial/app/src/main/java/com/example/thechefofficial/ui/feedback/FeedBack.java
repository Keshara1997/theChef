package com.example.thechefofficial.ui.feedback;

public class FeedBack {



    public String id;
    public String comment;
    public float rate;

    public FeedBack() {

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getComment() {
        return comment;
    }

    public void setComment(String comment) {
        this.comment = comment;
    }

    public float getRate() {
        return rate;
    }

    public void setRate(float rate) {
        this.rate = rate;
    }





}
